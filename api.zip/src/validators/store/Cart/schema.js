const Joi = require('joi');

const CartPostPayloadSchema = Joi.object({});

module.exports = { CartPostPayloadSchema };
