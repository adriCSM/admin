import Joi from 'joi';

const CartPostPayloadSchema = Joi.object({});

export default CartPostPayloadSchema;
