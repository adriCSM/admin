# Backend AdriCSM

## Project setup

```
npm install
```

## Eslint setup

```
npm init @eslint/config
```
